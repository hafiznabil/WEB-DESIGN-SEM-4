function createPost(additionalContent = "") {
 const postText = document.getElementById("postText").value;
 if (!postText && !additionalContent) return;

 const postHtml = `
		<div class="post-container">
			<div class="post-row">
				<div class="user-profile">
					<img src="images/profile-pic.png" alt="" />
					<div>
						<p>Hafiz Nabil</p>
						<span>${new Date().toLocaleString()}</span>
					</div>
				</div>
				<a href="#"><i class="fa-solid fa-ellipsis-v"></i></a>
			</div>
			<p class="post-text">${postText}</p>
			${additionalContent}
			<div class="post-row">
				<div class="activity-icons">
					<div onclick="handleLike(this)">
						<img src="images/like.png" class="like-icon" alt="" />
						<span class="like-count">1M</span>
					</div>
					<div onclick="handleComment(this)">
						<img src="images/comments.png" alt="" />
						<span class="comment-count">50K</span>
					</div>
					<div class="share-button" onclick="toggleShareMenu(this)">
						<img src="images/share.png" alt="" />
						<span class="share-count">124K</span>
						<div class="share-menu" style="display: none;">
							<span class="close-share" onclick="event.stopPropagation(); closeShareMenu(this)">&times;</span>
							<ul>
								<li><i class="fa-brands fa-facebook"></i> Facebook</li>
								<li><i class="fa-brands fa-twitter"></i> Twitter</li>
								<li><i class="fa-brands fa-whatsapp"></i> WhatsApp</li>
								<li><i class="fa-solid fa-link"></i> Copy Link</li>
							</ul>
						</div>
					</div>
				</div>
				<div class="post-profile-icon">
					<img src="images/profile-pic.png" alt="" />
					<i class="fa-solid fa-caret-down"></i>
				</div>
			</div>
		</div>
	`;

 const mainContent = document.querySelector(".main-content");
 const writePost = document.querySelector(".write-post-container");
 mainContent.insertBefore(
  document.createRange().createContextualFragment(postHtml),
  writePost.nextSibling
 );

 document.getElementById("postText").value = ""; // Clear the text input
}

function getCurrentDateTime() {
 const now = new Date();
 const months = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec",
 ];
 const month = months[now.getMonth()];
 const date = now.getDate();
 const year = now.getFullYear();
 const hours = now.getHours();
 const minutes = now.getMinutes().toString().padStart(2, "0");
 const ampm = hours >= 12 ? "pm" : "am";
 const formattedHours = hours % 12 || 12;

 return `${month} ${date} ${year}, ${formattedHours}:${minutes}${ampm}`;
}

function openLiveVideoModal() {
 document.getElementById("liveVideoModal").style.display = "block";
}

function openPhotoVideoModal() {
 document.getElementById("photoVideoModal").style.display = "block";
}

function openFeelingModal() {
 document.getElementById("feelingModal").style.display = "block";
}

function closeModal(modalId) {
 document.getElementById(modalId).style.display = "none";
}

function uploadMedia() {
 const fileInput = document.querySelector(
  '#photoVideoModal input[type="file"]'
 );
 const file = fileInput.files[0];

 if (!file) {
  alert("Please select a file first");
  return;
 }

 // Here you would typically upload to a server
 // For demo purposes, we'll create a preview
 const reader = new FileReader();
 reader.onload = function (e) {
  createPost(`<img src="${e.target.result}" style="max-width: 100%;" />`);
  closeModal("photoVideoModal");
  fileInput.value = ""; // Reset file input
 };
 reader.readAsDataURL(file);
}

function postFeeling() {
 const feeling = document.getElementById("feelingSelect").value;
 const feelingEmojis = {
  happy: "😊",
  sad: "😢",
  excited: "🎉",
  bored: "😑",
 };

 createPost(`Feeling ${feeling} ${feelingEmojis[feeling]}`);
 closeModal("feelingModal");
}

// Close modals when clicking outside
window.onclick = function (event) {
 const modals = document.getElementsByClassName("modal");
 for (let modal of modals) {
  if (event.target === modal) {
   modal.style.display = "none";
  }
 }
};

// Function to handle live video streaming
function startLiveVideo() {
 navigator.mediaDevices
  .getUserMedia({ video: true, audio: true })
  .then(function (stream) {
   const videoElement = document.createElement("video");
   videoElement.srcObject = stream;
   videoElement.autoplay = true;
   document
    .querySelector("#liveVideoModal .modal-content")
    .appendChild(videoElement);
  })
  .catch(function (err) {
   alert("Error accessing camera and microphone: " + err.message);
  });
}

// Function to handle likes
function handleLike(element) {
 const likeIcon = element.querySelector(".like-icon");
 const likeCount = element.querySelector(".like-count");

 // Toggle like status
 if (likeIcon.src.includes("like-blue.png")) {
  likeIcon.src = "images/like.png";
  let count = parseCount(likeCount.textContent);
  likeCount.textContent = formatCount(count - 1);
 } else {
  likeIcon.src = "images/like-blue.png";
  let count = parseCount(likeCount.textContent);
  likeCount.textContent = formatCount(count + 1);
 }
}

// Function to handle comments
function handleComment(element) {
 const postContainer = element.closest(".post-container");

 // Create comment section if it doesn't exist
 let commentSection = postContainer.querySelector(".comment-section");
 if (!commentSection) {
  commentSection = document.createElement("div");
  commentSection.className = "comment-section";
  commentSection.innerHTML = `
			<div class="comment-input">
				<input type="text" placeholder="Write a comment..." />
				<button onclick="postComment(this)">Post</button>
			</div>
			<div class="comments-list"></div>
		`;
  // Insert before the bottom post-row instead of after the top one
  postContainer.insertBefore(
   commentSection,
   postContainer.querySelector(".post-row:last-child")
  );
 } else {
  // Toggle comment section visibility
  commentSection.style.display =
   commentSection.style.display === "none" ? "block" : "none";
 }
}

// Function to post a comment
function postComment(button) {
 const commentInput = button.previousElementSibling;
 const commentText = commentInput.value.trim();

 if (commentText) {
  const commentsList = button
   .closest(".comment-section")
   .querySelector(".comments-list");
  const newComment = document.createElement("div");
  newComment.className = "comment";
  newComment.innerHTML = `
			<img src="images/profile-pic.png" alt="" class="comment-profile-pic" />
			<div class="comment-content">
				<p class="comment-author">Hafiz Nabil</p>
				<p class="comment-text">${commentText}</p>
			</div>
		`;
  commentsList.appendChild(newComment);

  // Update comment count
  const commentCount = button
   .closest(".post-container")
   .querySelector(".comment-count");
  let count = parseCount(commentCount.textContent);
  commentCount.textContent = formatCount(count + 1);

  // Clear input
  commentInput.value = "";
 }
}

// Share functionality
function toggleShareMenu(element) {
 const evt = window.event || arguments[0];
 evt.stopPropagation(); // Stop event bubbling

 const shareMenu = element.querySelector(".share-menu");
 const isCurrentlyOpen = shareMenu.style.display === "block";

 // First close all share menus
 closeAllShareMenus();

 // Then open this one if it wasn't already open
 if (!isCurrentlyOpen) {
  shareMenu.style.display = "block";
 }
}

// Helper function to close all share menus
function closeAllShareMenus() {
 const allShareMenus = document.querySelectorAll(".share-menu");
 allShareMenus.forEach((menu) => {
  menu.style.display = "none";
 });
}

function shareContent(platform, shareButton) {
 const postUrl = encodeURIComponent(window.location.href);
 const text = encodeURIComponent("Check out this post!");

 let shared = true;
 switch (platform) {
  case "facebook":
   window.open(
    `https://www.facebook.com/sharer/sharer.php?u=${postUrl}`,
    "_blank"
   );
   break;
  case "twitter":
   window.open(
    `https://twitter.com/intent/tweet?url=${postUrl}&text=${text}`,
    "_blank"
   );
   break;
  case "whatsapp":
   window.open(
    `https://api.whatsapp.com/send?text=${text}%20${postUrl}`,
    "_blank"
   );
   break;
  case "copy link":
   navigator.clipboard
    .writeText(window.location.href)
    .then(() => {
     alert("Link copied to clipboard!");
    })
    .catch((err) => {
     console.error("Failed to copy link:", err);
     alert("Failed to copy link. Please try again.");
     shared = false;
    });
   break;
  default:
   shared = false;
 }

 // Only increment share count if sharing was successful
 if (shared) {
  const shareCountElement = shareButton.querySelector(".share-count");
  if (shareCountElement) {
   let count = parseCount(shareCountElement.textContent);
   shareCountElement.textContent = formatCount(count + 1);
  }
 }
}

function closeShareMenu(element) {
 const evt = window.event || arguments[0];
 evt.stopPropagation(); // Prevent event from bubbling up
 closeAllShareMenus();
}

// Close share menu when clicking outside
document.addEventListener("click", function (event) {
 if (!event.target.closest(".share-button")) {
  closeAllShareMenus();
 }
});

function handleSearch(event) {
 const searchTerm = event.target.value.toLowerCase();
 const posts = document.querySelectorAll(".post-container");
 const users = document.querySelectorAll(".online-list");

 // Search through posts
 posts.forEach((post) => {
  const postText = post.querySelector(".post-text").textContent.toLowerCase();
  const userName = post
   .querySelector(".user-profile p")
   .textContent.toLowerCase();

  if (postText.includes(searchTerm) || userName.includes(searchTerm)) {
   post.style.display = "block";
  } else {
   post.style.display = "none";
  }
 });

 // Search through online users
 users.forEach((user) => {
  const userName = user.querySelector("p").textContent.toLowerCase();

  if (userName.includes(searchTerm)) {
   user.style.display = "flex";
  } else {
   user.style.display = "none";
  }
 });
}

// Optional: Add search on enter key press
document
 .getElementById("searchInput")
 .addEventListener("keypress", function (event) {
  if (event.key === "Enter") {
   handleSearch(event);
  }
 });
function settingsMenuToggle() {
 const settingsMenu = document.querySelector(".settings-menu");
 settingsMenu.classList.toggle("settings-menu-height");
}

function toggleDarkMode() {
 document.body.classList.toggle("dark-mode");
 // Save preference to localStorage
 const isDarkMode = document.body.classList.contains("dark-mode");
 localStorage.setItem("darkMode", isDarkMode);

 // Update the text of the toggle button
 const darkModeLink = document.querySelector('[onclick="toggleDarkMode()"] a');
 darkModeLink.textContent = isDarkMode
  ? "Toggle Light Mode"
  : "Toggle Dark Mode";
}

// Check for saved dark mode preference when page loads
document.addEventListener("DOMContentLoaded", () => {
 const isDarkMode = localStorage.getItem("darkMode") === "true";
 if (isDarkMode) {
  document.body.classList.add("dark-mode");
  const darkModeLink = document.querySelector('[onclick="toggleDarkMode()"] a');
  if (darkModeLink) {
   darkModeLink.textContent = "Toggle Light Mode";
  }
 }
});


// Function to handle login submission
function handleLogin(event) {
  event.preventDefault();
  const email = document.getElementById("loginEmail").value;
  const password = document.getElementById("loginPassword").value;

  // Example simple validation (replace with actual validation)
  if (email === "hafiznabil00@gmail.com" && password === "123456789") {
    window.location.href = "index.html";
  } else {
    alert("Invalid credentials, please try again.");
  }
}

// Function to handle sign-up submission
function handleSignUp(event) {
  event.preventDefault();
  alert("Sign-up successful!");
  showLogin(); // Redirect to login after successful sign-up
}

// Show Sign-Up Form
function showSignUp() {
  document.querySelector(".form-container").style.transform = "translateX(-50%)";
}

// Show Login Form
function showLogin() {
  document.querySelector(".form-container").style.transform = "translateX(0)";
}

const formContainer = document.querySelector('.form-container');
const switchFormLinks = document.querySelectorAll('.switch-form a');

switchFormLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        formContainer.style.transform = formContainer.style.transform === 'translateX(-50%)' ? 'translateX(0)' : 'translateX(-50%)';
    });
});
