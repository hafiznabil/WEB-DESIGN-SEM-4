// Global variables to track message state
let lastMessageTime = new Date();
const messageHistory = [];

// Toggle emoji picker visibility
function toggleEmojiPicker() {
 const picker = document.querySelector("emoji-picker");
 picker.style.display = picker.style.display === "none" ? "block" : "none";
}

// Handle emoji selection
document
 .querySelector("emoji-picker")
 .addEventListener("emoji-click", (event) => {
  const messageInput = document.getElementById("messageInput");
  messageInput.value += event.detail.unicode;
 });

// Handle file attachment
document.querySelector(".fa-paperclip").addEventListener("click", () => {
 // Create hidden file input
 const fileInput = document.createElement("input");
 fileInput.type = "file";
 fileInput.accept = "image/*,.pdf,.doc,.docx"; // Customize accepted file types

 fileInput.addEventListener("change", handleFileSelection);
 fileInput.click();
});

function handleFileSelection(event) {
 const file = event.target.files[0];
 if (file) {
  // For this example, we'll just show the file name in the message
  sendMessage(`Attached file: ${file.name}`);
  // In a real app, you'd upload the file to a server here
 }
}

// Send message function
function sendMessage(customText = null) {
 const messageInput = document.getElementById("messageInput");
 const messageText = customText || messageInput.value.trim();

 if (messageText === "") return;

 const chatMessages = document.querySelector(".chat-messages");
 const currentTime = new Date().toLocaleTimeString([], {
  hour: "2-digit",
  minute: "2-digit",
 });

 // Create new message element
 const messageDiv = document.createElement("div");
 messageDiv.className = "message sent";
 messageDiv.innerHTML = `
        <div class="message-content">
            <p>${messageText}</p>
            <span class="message-time">${currentTime}</span>
        </div>
    `;

 // Add message to chat
 chatMessages.appendChild(messageDiv);

 // Clear input
 if (!customText) messageInput.value = "";

 // Auto scroll to bottom
 chatMessages.scrollTop = chatMessages.scrollHeight;

 // Store message in history
 messageHistory.push({
  type: "sent",
  text: messageText,
  time: currentTime,
 });
}

// Handle send button click
document.querySelector(".chat-input button").addEventListener("click", () => {
 sendMessage();
});

// Handle enter key press
document.getElementById("messageInput").addEventListener("keypress", (e) => {
 if (e.key === "Enter") {
  sendMessage();
 }
});

// Load more messages
document
 .querySelector(".load-more-btn")
 .addEventListener("click", loadMoreMessages);

function loadMoreMessages() {
 // Example older messages
 const olderMessages = [
  {
   sender: "Melisa",
   text: "Can we meet tomorrow?",
   time: "09:45 AM",
   type: "received",
  },
  {
   sender: "You",
   text: "Sure, what time works for you?",
   time: "09:47 AM",
   type: "sent",
  },
  // Add more messages as needed
 ];

 const chatMessages = document.querySelector(".chat-messages");

 // Add older messages at the top
 olderMessages.reverse().forEach((msg) => {
  const messageDiv = document.createElement("div");
  messageDiv.className = `message ${msg.type}`;

  if (msg.type === "received") {
   messageDiv.innerHTML = `
                <img src="images/member-1.png" alt="${msg.sender}" />
                <div class="message-content">
                    <p>${msg.text}</p>
                    <span class="message-time">${msg.time}</span>
                </div>
            `;
  } else {
   messageDiv.innerHTML = `
                <div class="message-content">
                    <p>${msg.text}</p>
                    <span class="message-time">${msg.time}</span>
                </div>
            `;
  }

  chatMessages.insertBefore(messageDiv, chatMessages.firstChild);
 });
}

// Function to open chat with specific user
function openChat(username) {
 // Update chat header
 document.querySelector(".chat-user-name").textContent = username;

 // Clear existing messages
 document.querySelector(".chat-messages").innerHTML = "";

 // Load user-specific messages (example)
 const userMessages = {
  Melisa: [
   { type: "received", text: "Hey, how are you?", time: "10:30 AM" },
   { type: "sent", text: "I'm good! How about you?", time: "10:31 AM" },
  ],
  "Jack Haikal": [
   {
    type: "received",
    text: "Are we still on for the meeting?",
    time: "09:15 AM",
   },
  ],
  Riena: [
   {
    type: "received",
    text: "Looking forward to the party!",
    time: "Yesterday",
   },
  ],
 };

 // Display user-specific messages
 const messages = userMessages[username] || [];
 messages.forEach((msg) => {
  const messageDiv = document.createElement("div");
  messageDiv.className = `message ${msg.type}`;

  if (msg.type === "received") {
   messageDiv.innerHTML = `
                <img src="images/${
                 username === "Melisa"
                  ? "member-1"
                  : username === "Jack Haikal"
                  ? "member-2"
                  : "member-3"
                }.png" alt="${username}" />
                <div class="message-content">
                    <p>${msg.text}</p>
                    <span class="message-time">${msg.time}</span>
                </div>
            `;
  } else {
   messageDiv.innerHTML = `
                <div class="message-content">
                    <p>${msg.text}</p>
                    <span class="message-time">${msg.time}</span>
                </div>
            `;
  }

  document.querySelector(".chat-messages").appendChild(messageDiv);
 });
}

function settingsMenuToggle() {
 const settingsMenu = document.querySelector(".settings-menu");
 settingsMenu.classList.toggle("settings-menu-height");
}

function toggleDarkMode() {
 document.body.classList.toggle("dark-mode");
 // Save preference to localStorage
 const isDarkMode = document.body.classList.contains("dark-mode");
 localStorage.setItem("darkMode", isDarkMode);

 // Update the text of the toggle button
 const darkModeLink = document.querySelector('[onclick="toggleDarkMode()"] a');
 darkModeLink.textContent = isDarkMode
  ? "Toggle Light Mode"
  : "Toggle Dark Mode";
}

// Check for saved dark mode preference when page loads
document.addEventListener("DOMContentLoaded", () => {
 const isDarkMode = localStorage.getItem("darkMode") === "true";
 if (isDarkMode) {
  document.body.classList.add("dark-mode");
  const darkModeLink = document.querySelector('[onclick="toggleDarkMode()"] a');
  if (darkModeLink) {
   darkModeLink.textContent = "Toggle Light Mode";
  }
 }
});
