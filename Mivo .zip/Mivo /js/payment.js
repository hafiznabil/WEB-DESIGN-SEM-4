// Get the total amount from localStorage
const totalAmount = localStorage.getItem("totalAmount");

// Display the total amount in the payment page
if (totalAmount) {
  document.getElementById("paymentTotal").textContent = `RM ${totalAmount}`;
}

// Simulated card validation (for demo purposes only)
function isValidCardNumber(number) {
  // Simple check for demo - accepts any 16 digit number
  return number.length === 16;
}

// Show error message
function showError(message) {
  const errorDiv =
    document.getElementById("payment-error") ||
    (() => {
      const div = document.createElement("div");
      div.id = "payment-error";
      div.style.color = "red";
      document.getElementById("paymentForm").prepend(div);
      return div;
    })();
  errorDiv.textContent = message;
  setTimeout(() => (errorDiv.textContent = ""), 3000);
}

document.getElementById("paymentForm").addEventListener("submit", function (e) {
  e.preventDefault();

  // Get form values
  const cardName = document.getElementById("cardName").value;
  const cardNumber = document
    .getElementById("cardNumber")
    .value.replace(/\s/g, "");
  const expiry = document.getElementById("expiry").value;
  const cvv = document.getElementById("cvv").value.replace(/\s/g, "");

  // Basic demo validation
  if (!cardName.trim()) {
    showError("Please enter the cardholder name");
    return;
  }

  if (cardNumber.length !== 16) {
    showError("Please enter a 16-digit card number");
    return;
  }

  // Simple expiry validation for demo
  const [month, year] = expiry.split("/");
  if (!month || !year || month < 1 || month > 12) {
    showError("Please enter a valid expiry date (MM/YY)");
    return;
  }

  if (cvv.length !== 3) {
    showError("Please enter a 3-digit CVV");
    return;
  }

  // Clear cart after successful demo payment
  localStorage.removeItem("cartItems");

  // Create and show success modal
  const modal = document.createElement("div");
  modal.className = "success-modal";
  modal.innerHTML = `
        <h3>Demo Payment Successful! 🎉</h3>
        <p>This is a demo payment - no real transaction occurred.</p>
    `;

  const overlay = document.createElement("div");
  overlay.className = "overlay";

  // Add click listener to close modal
  const closeModal = () => {
    overlay.remove();
    modal.remove();
    window.location.href = "index.html"; // Redirect back to the home page
  };

  overlay.addEventListener("click", closeModal);

  document.body.appendChild(overlay);
  document.body.appendChild(modal);

  setTimeout(() => {
    overlay.classList.add("show");
    modal.classList.add("show");
  }, 100);

  setTimeout(closeModal, 2000);
});

// Format cardholder name input
document.getElementById("cardName").addEventListener("input", function (e) {
  let value = e.target.value
    .replace(/\s+/g, " ")
    .replace(/[^a-zA-Z\s]/g, "")
    .toLowerCase()
    .split(" ")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
  e.target.value = value;
});

// Format card number input (demo formatting)
document.getElementById("cardNumber").addEventListener("input", function (e) {
  let value = e.target.value.replace(/\D/g, "").substring(0, 16);
  let formattedValue = value.replace(/(\d{4})(?=\d)/g, "$1 ");
  e.target.value = formattedValue;
});

// Format expiry date input
document.getElementById("expiry").addEventListener("input", function (e) {
  let value = e.target.value.replace(/\D/g, "");
  if (value.length >= 2) {
    const month = value.slice(0, 2);
    if (parseInt(month) > 12) value = "12" + value.slice(2);
    value = value.slice(0, 2) + "/" + value.slice(2);
  }
  e.target.value = value.slice(0, 5);
});

// Format CVV input - numbers only, no spaces
document.getElementById("cvv").addEventListener("input", function (e) {
  e.target.value = e.target.value.replace(/\D/g, "").slice(0, 3);
});
