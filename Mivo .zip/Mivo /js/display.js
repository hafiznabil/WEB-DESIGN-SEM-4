// Get DOM elements
const fontSizeSelect = document.getElementById("fontSize");
const contrastSelect = document.getElementById("contrast");
const reduceMotionToggle = document.getElementById("reduceMotion");
const saveButton = document.querySelector(".save-settings");

// Load saved settings on page load
document.addEventListener("DOMContentLoaded", () => {
 loadSettings();
});

// Save settings when button is clicked
saveButton.addEventListener("click", () => {
 saveSettings();
 alert("Settings saved successfully!");
});

// Function to save settings to localStorage
function saveSettings() {
 const settings = {
  fontSize: fontSizeSelect.value,
  contrast: contrastSelect.value,
  reduceMotion: reduceMotionToggle.checked,
 };

 localStorage.setItem("displaySettings", JSON.stringify(settings));
 applySettings(settings);
}

// Function to load settings from localStorage
function loadSettings() {
 const savedSettings = localStorage.getItem("displaySettings");
 if (savedSettings) {
  const settings = JSON.parse(savedSettings);

  // Update form elements with saved values
  fontSizeSelect.value = settings.fontSize;
  contrastSelect.value = settings.contrast;
  reduceMotionToggle.checked = settings.reduceMotion;

  // Apply the settings
  applySettings(settings);
 }
}

// Function to apply settings to the page
function applySettings(settings) {
 // Apply font size
 document.body.style.fontSize = getFontSize(settings.fontSize);

 // Apply contrast
 if (settings.contrast === "high") {
  document.body.classList.add("high-contrast");
 } else {
  document.body.classList.remove("high-contrast");
 }

 // Apply reduce motion
 if (settings.reduceMotion) {
  document.body.classList.add("reduce-motion");
 } else {
  document.body.classList.remove("reduce-motion");
 }
}

// Helper function to get font size value
function getFontSize(size) {
 const sizes = {
  small: "14px",
  medium: "16px",
  large: "18px",
 };
 return sizes[size] || sizes.medium;
}
