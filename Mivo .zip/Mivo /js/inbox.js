// DOM Elements
const inboxFilter = document.querySelector(".inbox-filter select");
const categoryButtons = document.querySelectorAll(
 ".inbox-categories .category"
);
const inboxList = document.querySelector(".inbox-list");
const loadMoreBtn = document.querySelector(".load-more-btn");
const emptyInbox = document.querySelector(".empty-inbox");

// Inbox Filter Function
inboxFilter.addEventListener("change", (e) => {
 const filterValue = e.target.value;
 const messages = document.querySelectorAll(".inbox-item");

 messages.forEach((message) => {
  switch (filterValue) {
   case "unread":
    message.style.display = message.classList.contains("unread")
     ? "flex"
     : "none";
    break;
   case "read":
    message.style.display = !message.classList.contains("unread")
     ? "flex"
     : "none";
    break;
   default: // 'all'
    message.style.display = "flex";
  }
 });

 checkEmptyInbox();
});

// Inbox Categories Function
categoryButtons.forEach((button) => {
 button.addEventListener("click", () => {
  // Remove active class from all buttons
  categoryButtons.forEach((btn) => btn.classList.remove("active"));
  // Add active class to clicked button
  button.classList.add("active");

  // Here you would typically filter messages based on category
  // For demo purposes, we'll just console.log the category
  console.log(`Switched to ${button.textContent} category`);
 });
});

// Message Action Functions
function setupMessageActions() {
 const actionButtons = document.querySelectorAll(".action-buttons button");

 actionButtons.forEach((button) => {
  button.addEventListener("click", (e) => {
   const messageItem = e.target.closest(".inbox-item");

   if (button.title === "Mark as read") {
    messageItem.classList.remove("unread");
    updateUnreadCount();
   } else if (button.title === "Delete") {
    messageItem.remove();
    checkEmptyInbox();
   } else if (button.title === "Archive") {
    messageItem.classList.add("archived");
    messageItem.setAttribute("data-category", "archive");

    // Add animation
    messageItem.style.animation = "slideOut 0.3s ease-out";

    // Only hide if not in archive view
    if (
     !document
      .querySelector('.category[data-category="archive"]')
      .classList.contains("active")
    ) {
     setTimeout(() => {
      messageItem.style.display = "none";
     }, 300);
    }

    checkEmptyInbox();
   }
  });
 });
}

// Update unread count in notification badge
function updateUnreadCount() {
 const unreadCount = document.querySelectorAll(".inbox-item.unread").length;
 const badge = document.querySelector(".notification-badge");
 if (badge) {
  badge.textContent = unreadCount;
  badge.style.display = unreadCount > 0 ? "inline" : "none";
 }
}

// Check if inbox is empty
function checkEmptyInbox() {
 const visibleMessages = Array.from(
  document.querySelectorAll(".inbox-item")
 ).filter((item) => item.style.display !== "none");

 if (visibleMessages.length === 0) {
  emptyInbox.style.display = "flex";
  loadMoreBtn.style.display = "none";
 } else {
  emptyInbox.style.display = "none";
  loadMoreBtn.style.display = "block";
 }
}

// Load More Messages Function
let messageCount = 3; // Starting number of messages
loadMoreBtn.addEventListener("click", () => {
 // Example of loading more messages
 const newMessages = [
  {
   name: "Sarah",
   preview: "About the project deadline...",
   time: "2 days ago",
   image: "images/member-4.png",
  },
  {
   name: "Mike",
   preview: "Great work on the presentation!",
   time: "3 days ago",
   image: "images/member-5.png",
  },
 ];

 // Add new messages to the list
 newMessages.forEach((msg) => {
  const messageHTML = `
            <div class="inbox-item">
                <div class="user-profile">
                    <img src="${msg.image}" alt="${msg.name}" />
                    <div>
                        <p>${msg.name}</p>
                        <p class="inbox-preview">${msg.preview}</p>
                    </div>
                </div>
                <div class="message-actions">
                    <span class="inbox-time">${msg.time}</span>
                    <div class="action-buttons">
                        <button title="Mark as read">
                            <i class="fas fa-envelope-open"></i>
                        </button>
                        <button title="Delete"><i class="fas fa-trash"></i></button>
                        <button title="Archive"><i class="fas fa-archive"></i></button>
                    </div>
                </div>
            </div>
        `;
  inboxList.insertAdjacentHTML("beforeend", messageHTML);
 });

 // Update message actions for new messages
 setupMessageActions();

 // Hide load more button if no more messages
 messageCount += newMessages.length;
 if (messageCount >= 7) {
  // Example maximum number of messages
  loadMoreBtn.style.display = "none";
 }
});

// Initial setup
setupMessageActions();
updateUnreadCount();
checkEmptyInbox();

// Add event listener for archive category button
document
 .querySelector('.category[class*="Archive"]')
 .addEventListener("click", function () {
  // Remove active class from all category buttons
  document
   .querySelectorAll(".category")
   .forEach((btn) => btn.classList.remove("active"));

  // Add active class to archive button
  this.classList.add("active");

  // Show archived messages and hide others
  const inboxList = document.querySelector(".inbox-list");
  const emptyInbox = document.querySelector(".empty-inbox");

  // Get archived messages (you'll need to add 'archived' class to messages when they're archived)
  const archivedMessages = document.querySelectorAll(".inbox-item.archived");

  // Hide all messages first
  document.querySelectorAll(".inbox-item").forEach((item) => {
   item.style.display = "none";
  });

  // Show archived messages
  archivedMessages.forEach((message) => {
   message.style.display = "flex";
  });

  // Show empty inbox message if no archived messages
  if (archivedMessages.length === 0) {
   emptyInbox.style.display = "flex";
   emptyInbox.querySelector("h3").textContent = "No archived messages";
   emptyInbox.querySelector("p").textContent =
    "Messages you archive will appear here";
  } else {
   emptyInbox.style.display = "none";
  }
 });

// Add this CSS to your inbox.css file
const style = document.createElement("style");
style.textContent = `
    @keyframes slideOut {
        from {
            opacity: 1;
            transform: translateX(0);
        }
        to {
            opacity: 0;
            transform: translateX(100%);
        }
    }
`;
document.head.appendChild(style);

document.addEventListener("DOMContentLoaded", function () {
 const categoryButtons = document.querySelectorAll(
  ".inbox-categories .category"
 );
 const inboxItems = document.querySelectorAll(".inbox-item");

 // Add click event listeners to category buttons
 categoryButtons.forEach((button) => {
  button.addEventListener("click", function () {
   // Remove active class from all buttons
   categoryButtons.forEach((btn) => btn.classList.remove("active"));
   // Add active class to clicked button
   this.classList.add("active");

   const selectedCategory = this.getAttribute("data-category");

   // Show/hide messages based on category
   inboxItems.forEach((item) => {
    if (selectedCategory === "archive") {
     // Show only archived messages
     item.style.display =
      item.getAttribute("data-category") === "archive" ? "flex" : "none";
    } else {
     // Show messages for other categories
     item.style.display =
      item.getAttribute("data-category") === selectedCategory ? "flex" : "none";
    }
   });

   // Show empty inbox message if no messages in category
   const visibleMessages = document.querySelectorAll(
    '.inbox-item[style="display: flex"]'
   );
   const emptyInbox = document.querySelector(".empty-inbox");
   if (visibleMessages.length === 0) {
    emptyInbox.style.display = "block";
   } else {
    emptyInbox.style.display = "none";
   }
  });
 });

 // When "Archive" button is clicked in message actions
 document
  .querySelectorAll('.action-buttons button[title="Archive"]')
  .forEach((button) => {
   button.addEventListener("click", function () {
    const inboxItem = this.closest(".inbox-item");
    inboxItem.setAttribute("data-category", "archive");
    if (
     document
      .querySelector('.category[data-category="archive"]')
      .classList.contains("active")
    ) {
     inboxItem.style.display = "flex";
    } else {
     inboxItem.style.display = "none";
    }
   });
  });
});

// Function to handle compose button click
function handleCompose() {
 // Create compose modal
 const composeModal = document.createElement("div");
 composeModal.className = "compose-modal";
 composeModal.innerHTML = `
        <div class="compose-content">
            <div class="compose-header">
                <h3>New Message</h3>
                <button class="close-btn">&times;</button>
            </div>
            <form class="compose-form">
                <input type="text" placeholder="To" required>
                <input type="text" placeholder="Subject">
                <textarea placeholder="Write your message here..." required></textarea>
                <div class="compose-actions">
                    <button type="submit" class="send-btn">
                        <i class="fas fa-paper-plane"></i> Send
                    </button>
                    <button type="button" class="discard-btn">
                        <i class="fas fa-trash"></i> Discard
                    </button>
                </div>
            </form>
        </div>
    `;

 // Add modal to body
 document.body.appendChild(composeModal);

 // Add event listeners
 const closeBtn = composeModal.querySelector(".close-btn");
 const discardBtn = composeModal.querySelector(".discard-btn");
 const composeForm = composeModal.querySelector(".compose-form");

 // Close modal function
 const closeModal = () => {
  composeModal.remove();
 };

 // Event listeners
 closeBtn.addEventListener("click", closeModal);
 discardBtn.addEventListener("click", closeModal);

 // Handle form submission
 composeForm.addEventListener("submit", (e) => {
  e.preventDefault();
  // Add your message sending logic here
  alert("Message sent!"); // Placeholder
  closeModal();
 });

 // Close modal if clicking outside
 composeModal.addEventListener("click", (e) => {
  if (e.target === composeModal) {
   closeModal();
  }
 });
}

// Add click event listener to compose button
document.addEventListener("DOMContentLoaded", () => {
 const composeBtn = document.querySelector(".compose-btn");
 composeBtn.addEventListener("click", handleCompose);
});
function settingsMenuToggle() {
 const settingsMenu = document.querySelector(".settings-menu");
 settingsMenu.classList.toggle("settings-menu-height");
}

function toggleDarkMode() {
 document.body.classList.toggle("dark-mode");
 // Save preference to localStorage
 const isDarkMode = document.body.classList.contains("dark-mode");
 localStorage.setItem("darkMode", isDarkMode);

 // Update the text of the toggle button
 const darkModeLink = document.querySelector('[onclick="toggleDarkMode()"] a');
 if (darkModeLink) {
  darkModeLink.textContent = isDarkMode
   ? "Toggle Light Mode"
   : "Toggle Dark Mode";
 }
}

// Check dark mode preference immediately
const savedDarkMode = localStorage.getItem("darkMode") === "true";
if (savedDarkMode) {
 document.body.classList.add("dark-mode");
}

// Additional setup when DOM is loaded
document.addEventListener("DOMContentLoaded", () => {
 if (savedDarkMode) {
  const darkModeLink = document.querySelector('[onclick="toggleDarkMode()"] a');
  if (darkModeLink) {
   darkModeLink.textContent = "Toggle Light Mode";
  }
 }
});
