document.addEventListener("DOMContentLoaded", () => {
    // Get cart items from localStorage
    const cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];
    const totalAmount = localStorage.getItem("totalAmount");
  
    const receiptItemsList = document.getElementById("receiptItemsList");
    const totalAmountElement = document.getElementById("totalAmount");
  
    if (cartItems.length === 0) {
      receiptItemsList.innerHTML = "<tr><td colspan='3'>No items found in your cart.</td></tr>";
    } else {
      let cartHTML = "";
      cartItems.forEach((item) => {
        cartHTML += `
          <tr>
            <td>${item.name}</td>
            <td>${item.quantity}</td>
            <td>RM ${item.price.toFixed(2)}</td>
          </tr>
        `;
      });
      receiptItemsList.innerHTML = cartHTML;
    }
  
    if (totalAmount) {
      totalAmountElement.textContent = `RM ${totalAmount}`;
    }
  });
  