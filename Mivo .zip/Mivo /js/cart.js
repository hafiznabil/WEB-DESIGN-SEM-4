// Display cart items when the page loads
document.addEventListener("DOMContentLoaded", () => {
  displayCartItems();
  updateCartCount();
});

// Function to display items in the cart
function displayCartItems() {
  const cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];
  const cartItemsContainer = document.getElementById("cartItems");
  const totalElement = document.getElementById("cartTotal");

  if (!cartItemsContainer) return;

  if (cartItems.length === 0) {
    cartItemsContainer.innerHTML = '<p class="empty-cart">Your cart is empty</p>';
    totalElement.textContent = "0.00";
    return;
  }

  let total = 0;
  let cartHTML = "";

  cartItems.forEach((item) => {
    total += item.price * item.quantity;

    cartHTML += `
      <div class="cart-item">
        <div class="cart-item-image">
          <img src="${item.image}" alt="${item.name}">
        </div>
        <div class="item-details">
          <h3>${item.name}</h3>
          <p class="item-price">RM ${item.price.toFixed(2)}</p>
          <div class="quantity">
            <button onclick="updateQuantity(${item.id}, -1)">-</button>
            <span>${item.quantity}</span>
            <button onclick="updateQuantity(${item.id}, 1)">+</button>
          </div>
        </div>
        <button onclick="removeItem(${item.id})" class="remove-btn">Remove</button>
      </div>
    `;
  });

  cartItemsContainer.innerHTML = cartHTML;
  totalElement.textContent = total.toFixed(2);
}

// Function to update quantity and adjust price
function updateQuantity(productId, change) {
  let cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];
  const itemIndex = cartItems.findIndex((item) => item.id === productId);

  if (itemIndex !== -1) {
    cartItems[itemIndex].quantity = Math.max(0, cartItems[itemIndex].quantity + change);

    if (change > 0) {
      // When quantity increases, multiply price by 1 (price stays the same)
      cartItems[itemIndex].price *= 1; // This is effectively no change
    } else if (change < 0 && cartItems[itemIndex].quantity > 0) {
      // When quantity decreases, divide price by 1 (price stays the same)
      cartItems[itemIndex].price /= 1; // This is effectively no change
    }

    // If quantity reaches 0, remove the item from the cart
    if (cartItems[itemIndex].quantity === 0) {
      cartItems = cartItems.filter((item) => item.id !== productId);
    }

    localStorage.setItem("cartItems", JSON.stringify(cartItems));
    displayCartItems();
    updateCartCount();
  }
}

// Function to remove an item from the cart
function removeItem(productId) {
  let cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];
  cartItems = cartItems.filter((item) => item.id !== productId);
  localStorage.setItem("cartItems", JSON.stringify(cartItems));
  displayCartItems();
  updateCartCount();
}

// Function to update the cart count in the navbar
function updateCartCount() {
  const cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];
  const count = cartItems.reduce((total, item) => total + item.quantity, 0);
  const cartCountElement = document.querySelector(".cart-count");
  if (cartCountElement) {
    cartCountElement.textContent = count;
  }
}

// Function to handle the checkout process
function checkout() {
  const cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];
  if (cartItems.length === 0) {
    alert("Your cart is empty!");
    return;
  }

  alert("Processing your order...");
  localStorage.removeItem("cartItems");
  displayCartItems();
  updateCartCount();
}
