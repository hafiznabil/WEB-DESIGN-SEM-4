function settingsMenuToggle() {
 const settingsMenu = document.querySelector(".settings-menu");
 settingsMenu.classList.toggle("settings-menu-height");
}

function toggleDarkMode() {
 document.body.classList.toggle("dark-mode");
 // Save preference to localStorage
 const isDarkMode = document.body.classList.contains("dark-mode");
 localStorage.setItem("darkMode", isDarkMode);

 // Update the text of the toggle button
 const darkModeLink = document.querySelector('[onclick="toggleDarkMode()"] a');
 darkModeLink.textContent = isDarkMode
  ? "Toggle Light Mode"
  : "Toggle Dark Mode";
}

// Check for saved dark mode preference when page loads
document.addEventListener("DOMContentLoaded", () => {
 const isDarkMode = localStorage.getItem("darkMode") === "true";
 if (isDarkMode) {
  document.body.classList.add("dark-mode");
  const darkModeLink = document.querySelector('[onclick="toggleDarkMode()"] a');
  if (darkModeLink) {
   darkModeLink.textContent = "Toggle Light Mode";
  }
 }
});

// Close settings menu when clicking outside
document.addEventListener("click", (e) => {
 const settingsMenu = document.querySelector(".settings-menu");
 const userIcon = document.querySelector(".nav-user-icon");

 if (!settingsMenu.contains(e.target) && !userIcon.contains(e.target)) {
  settingsMenu.classList.remove("settings-menu-height");
 }
});

// Function to handle activity filtering
function initializeActivityFilters() {
 const filterButtons = document.querySelectorAll(".filter-btn");
 const activityPosts = document.querySelectorAll(".activity-post");

 filterButtons.forEach((button) => {
  button.addEventListener("click", () => {
   // Remove active class from all buttons
   filterButtons.forEach((btn) => btn.classList.remove("active"));
   // Add active class to clicked button
   button.classList.add("active");

   // Get the filter type from the button text
   const filterType = button.textContent.trim().toLowerCase();

   // Show/hide posts based on filter
   activityPosts.forEach((post) => {
    const activityType = post
     .querySelector(".user-profile span")
     .textContent.toLowerCase();

    if (filterType === "all") {
     post.style.display = "block";
    } else {
     // Check if the activity type contains the filter keyword
     if (filterType === "likes" && activityType.includes("liked")) {
      post.style.display = "block";
     } else if (filterType === "comments" && activityType.includes("comment")) {
      post.style.display = "block";
     } else if (filterType === "mentions" && activityType.includes("mention")) {
      post.style.display = "block";
     } else if (filterType === "shares" && activityType.includes("shared")) {
      post.style.display = "block";
     } else {
      post.style.display = "none";
     }
    }
   });

   // Show empty state if no posts are visible
   const visiblePosts = document.querySelectorAll(
    '.activity-post[style="display: block"]'
   );
   const emptyState = document.querySelector(".empty-state");
   if (visiblePosts.length === 0) {
    emptyState.style.display = "flex";
   } else {
    emptyState.style.display = "none";
   }
  });
 });
}

// Initialize filters when the DOM is loaded
document.addEventListener("DOMContentLoaded", initializeActivityFilters);

// Get all interaction buttons
document.addEventListener("DOMContentLoaded", () => {
 // Like back functionality
 const likeButtons = document.querySelectorAll(".like-btn");
 likeButtons.forEach((button) => {
  button.addEventListener("click", function () {
   // Toggle active state
   this.classList.toggle("active");

   // Change icon color and text
   if (this.classList.contains("active")) {
    this.innerHTML =
     '<i class="fas fa-heart" style="color: #e74c3c;"></i> Liked';
    showNotification("Liked successfully!");
   } else {
    this.innerHTML = '<i class="fas fa-heart"></i> Like back';
   }
  });
 });

 // Reply functionality
 const commentButtons = document.querySelectorAll(".comment-btn");
 commentButtons.forEach((button) => {
  button.addEventListener("click", function () {
   // Find the closest activity post
   const activityPost = this.closest(".activity-post");

   // Check if reply form already exists
   if (!activityPost.querySelector(".reply-form")) {
    // Create reply form
    const replyForm = document.createElement("div");
    replyForm.className = "reply-form";
    replyForm.innerHTML = `
    <textarea 
        placeholder="Write your reply..." 
        style="
            width: 100%;
            padding: 12px 16px;
            border: 1px solid #e1e1e1;
            border-radius: 8px;
            background: #f8f9fa;
            font-size: 14px;
            resize: vertical;
            min-height: 80px;
            margin-bottom: 12px;
            transition: border-color 0.2s, box-shadow 0.2s;
        "
    ></textarea>
    <div class="reply-actions" style="
        display: flex;
        gap: 8px;
        justify-content: flex-end;
    ">
        <button class="cancel-reply" style="
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            background: #f0f0f0;
            color: #666;
            transition: background 0.2s;
        ">Cancel</button>
        <button class="submit-reply" style="
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            background: #1a73e8;
            color: white;
            transition: background 0.2s;
        ">Send</button>
    </div>
`;

    // Insert form after post interactions
    this.closest(".post-interactions").after(replyForm);

    // Handle submit reply
    replyForm.querySelector(".submit-reply").addEventListener("click", () => {
     const replyText = replyForm.querySelector("textarea").value;
     if (replyText.trim()) {
      showNotification("Reply sent successfully!");
      replyForm.remove();
     }
    });

    // Handle cancel reply
    replyForm.querySelector(".cancel-reply").addEventListener("click", () => {
     replyForm.remove();
    });
   }
  });
 });

 // Share functionality
 const shareButtons = document.querySelectorAll(".share-btn");
 shareButtons.forEach((button) => {
  button.addEventListener("click", function () {
   // Find the post content
   const activityPost = this.closest(".activity-post");
   const postPreview =
    activityPost.querySelector(".post-preview p").textContent;

   // Create share options
   const shareOptions = document.createElement("div");
   shareOptions.className = "share-options";
   shareOptions.innerHTML = `
                <div class="share-popup">
                    <button class="share-option" data-platform="facebook">
                        <i class="fab fa-facebook"></i> Facebook
                    </button>
                    <button class="share-option" data-platform="twitter">
                        <i class="fab fa-twitter"></i> Twitter
                    </button>
                    <button class="share-option" data-platform="linkedin">
                        <i class="fab fa-linkedin"></i> LinkedIn
                    </button>
                    <button class="share-option" data-platform="copy">
                        <i class="fas fa-link"></i> Copy Link
                    </button>
                    <button class="close-share">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            `;

   // Remove existing share options if any
   document
    .querySelectorAll(".share-options")
    .forEach((popup) => popup.remove());

   // Add share options to document
   document.body.appendChild(shareOptions);

   // Position the popup near the share button
   const buttonRect = this.getBoundingClientRect();
   shareOptions.style.position = "absolute";
   shareOptions.style.top = `${buttonRect.bottom + window.scrollY + 10}px`;
   shareOptions.style.left = `${buttonRect.left}px`;

   // Handle share options clicks
   shareOptions.querySelectorAll(".share-option").forEach((option) => {
    option.addEventListener("click", () => {
     const platform = option.dataset.platform;
     shareContent(platform, postPreview);
     shareOptions.remove();
    });
   });

   // Close share options
   shareOptions.querySelector(".close-share").addEventListener("click", () => {
    shareOptions.remove();
   });

   // Close share options when clicking outside
   document.addEventListener("click", function closeShare(e) {
    if (!shareOptions.contains(e.target) && !button.contains(e.target)) {
     shareOptions.remove();
     document.removeEventListener("click", closeShare);
    }
   });
  });
 });
});

// Helper function to share content
function shareContent(platform, content) {
 switch (platform) {
  case "facebook":
   window.open(
    `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(
     window.location.href
    )}`
   );
   break;
  case "twitter":
   window.open(
    `https://twitter.com/intent/tweet?text=${encodeURIComponent(
     content
    )}&url=${encodeURIComponent(window.location.href)}`
   );
   break;
  case "linkedin":
   window.open(
    `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(
     window.location.href
    )}`
   );
   break;
  case "copy":
   navigator.clipboard
    .writeText(window.location.href)
    .then(() => showNotification("Link copied to clipboard!"));
   break;
 }
}

// Helper function to show notifications
function showNotification(message) {
 // Create notification element
 const notification = document.createElement("div");
 notification.className = "notification";
 notification.textContent = message;

 // Add styles
 notification.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        background-color: #333;
        color: white;
        padding: 12px 24px;
        border-radius: 4px;
        z-index: 1000;
        animation: slideIn 0.3s ease-out;
    `;

 // Add animation keyframes
 if (!document.querySelector("#notification-styles")) {
  const style = document.createElement("style");
  style.id = "notification-styles";
  style.textContent = `
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
        `;
  document.head.appendChild(style);
 }

 // Add to document and remove after delay
 document.body.appendChild(notification);
 setTimeout(() => {
  notification.style.animation = "slideIn 0.3s ease-out reverse";
  setTimeout(() => notification.remove(), 300);
 }, 3000);
}

// Function to handle create new post
function createNewPost() {
 // Create modal overlay
 const modal = document.createElement("div");
 modal.className = "post-modal";

 // Create modal content
 modal.innerHTML = `
        <div class="post-modal-content">
            <div class="post-modal-header">
                <h3>Create New Post</h3>
                <button class="close-modal">&times;</button>
            </div>
            <div class="post-modal-body">
                <textarea placeholder="What's on your mind?" rows="4"></textarea>
                <div class="post-attachments">
                    <button class="attachment-btn">
                        <i class="fas fa-image"></i> Photo/Video
                    </button>
                    <button class="attachment-btn">
                        <i class="fas fa-map-marker-alt"></i> Location
                    </button>
                </div>
            </div>
            <div class="post-modal-footer">
                <button class="post-btn">Post</button>
            </div>
        </div>
    `;

 // Add modal to body
 document.body.appendChild(modal);

 // Add event listeners
 const closeBtn = modal.querySelector(".close-modal");
 const postBtn = modal.querySelector(".post-btn");

 closeBtn.addEventListener("click", () => {
  modal.remove();
 });

 postBtn.addEventListener("click", () => {
  const content = modal.querySelector("textarea").value;
  if (content.trim()) {
   // Here you would typically send the post to your backend
   alert("Post created successfully!");
   modal.remove();
  } else {
   alert("Please write something before posting!");
  }
 });

 // Close modal when clicking outside
 modal.addEventListener("click", (e) => {
  if (e.target === modal) {
   modal.remove();
  }
 });

 // Add these lines after creating the modal content
 const attachmentBtns = modal.querySelectorAll(".attachment-btn");
 const photoVideoBtn = attachmentBtns[0];
 const locationBtn = attachmentBtns[1];

 // Create hidden file input
 const fileInput = document.createElement("input");
 fileInput.type = "file";
 fileInput.accept = "image/*,video/*";
 fileInput.multiple = true;
 fileInput.style.display = "none";
 modal.appendChild(fileInput);

 // Add preview container
 const previewContainer = document.createElement("div");
 previewContainer.className = "attachment-previews";
 modal.querySelector(".post-modal-body").appendChild(previewContainer);

 // Photo/Video button handler
 photoVideoBtn.addEventListener("click", () => {
  fileInput.click();
 });

 // File input change handler
 fileInput.addEventListener("change", () => {
  previewContainer.innerHTML = ""; // Clear previous previews
  Array.from(fileInput.files).forEach((file) => {
   const preview = document.createElement("div");
   preview.className = "attachment-preview";

   if (file.type.startsWith("image/")) {
    const img = document.createElement("img");
    img.src = URL.createObjectURL(file);
    preview.appendChild(img);
   } else if (file.type.startsWith("video/")) {
    const video = document.createElement("video");
    video.src = URL.createObjectURL(file);
    video.controls = true;
    preview.appendChild(video);
   }

   const removeBtn = document.createElement("button");
   removeBtn.innerHTML = "×";
   removeBtn.className = "remove-attachment";
   removeBtn.onclick = () => preview.remove();

   preview.appendChild(removeBtn);
   previewContainer.appendChild(preview);
  });
 });

 // Location button handler
 locationBtn.addEventListener("click", () => {
  if ("geolocation" in navigator) {
   locationBtn.disabled = true;
   locationBtn.innerHTML =
    '<i class="fas fa-spinner fa-spin"></i> Getting location...';

   navigator.geolocation.getCurrentPosition(
    async (position) => {
     try {
      const response = await fetch(
       `https://nominatim.openstreetmap.org/reverse?lat=${position.coords.latitude}&lon=${position.coords.longitude}&format=json`
      );
      const data = await response.json();

      const locationPreview = document.createElement("div");
      locationPreview.className = "location-preview";
      locationPreview.innerHTML = `
                            <i class="fas fa-map-marker-alt"></i>
                            <span>${data.display_name}</span>
                            <button class="remove-location">×</button>
                        `;

      locationPreview.querySelector(".remove-location").onclick = () => {
       locationPreview.remove();
       locationBtn.disabled = false;
      };

      previewContainer.appendChild(locationPreview);
     } catch (error) {
      console.error("Error getting location:", error);
      alert("Could not get location details. Please try again.");
     } finally {
      locationBtn.innerHTML = '<i class="fas fa-map-marker-alt"></i> Location';
      locationBtn.disabled = false;
     }
    },
    (error) => {
     console.error("Geolocation error:", error);
     alert(
      "Could not get your location. Please check your permissions and try again."
     );
     locationBtn.innerHTML = '<i class="fas fa-map-marker-alt"></i> Location';
     locationBtn.disabled = false;
    }
   );
  } else {
   alert("Geolocation is not supported by your browser");
  }
 });

 // Modify the post button handler to include attachments
 postBtn.addEventListener("click", () => {
  const content = modal.querySelector("textarea").value;
  if (content.trim()) {
   // Here you would typically send the post to your backend
   // Including the files from fileInput.files
   // and any location data from the location preview
   alert("Post created successfully!");
   modal.remove();
  } else {
   alert("Please write something before posting!");
  }
 });
}

// Add event listener to the create post button
document
 .querySelector(".create-post-btn")
 .addEventListener("click", createNewPost);

// Load more activities
document.addEventListener("DOMContentLoaded", function () {
 const loadMoreBtn = document.querySelector(".load-more-btn");
 const spinner = loadMoreBtn.querySelector(".fa-spinner");
 const btnText = loadMoreBtn.querySelector("span");
 let page = 1;

 loadMoreBtn.addEventListener("click", async function () {
  // Show loading state
  spinner.style.display = "inline-block";
  btnText.textContent = "Loading...";
  loadMoreBtn.disabled = true;

  try {
   // Simulate loading delay (replace this with actual API call)
   await new Promise((resolve) => setTimeout(resolve, 1500));

   // Example activity template
   const newActivity = `
                <div class="activity-post">
                    <div class="activity-header">
                        <div class="user-profile">
                            <img src="images/member-${
                             Math.floor(Math.random() * 9) + 1
                            }.png" alt="User">
                            <div>
                                <p>New User ${page}</p>
                                <span>Liked your post</span>
                                <small>${page} hours ago</small>
                            </div>
                        </div>
                        <div class="post-preview">
                            <p>"New activity content ${page}..."</p>
                            <small>Original post from March ${page}, 2024</small>
                        </div>
                    </div>
                    <div class="post-interactions">
                        <button class="interaction-btn like-btn">
                            <i class="fas fa-heart"></i> Like back
                        </button>
                        <button class="interaction-btn comment-btn">
                            <i class="fas fa-comment"></i> Reply
                        </button>
                        <button class="interaction-btn share-btn">
                            <i class="fas fa-share"></i> Share
                        </button>
                    </div>
                </div>
            `;

   // Add new content to the feed
   const activityFeed = document.querySelector(".activity-feed");
   activityFeed.insertAdjacentHTML("beforeend", newActivity);

   // Get the newly added post
   const newPost = activityFeed.lastElementChild;

   // Add like button functionality
   const likeBtn = newPost.querySelector(".like-btn");
   likeBtn.addEventListener("click", function () {
    this.classList.toggle("active");
    if (this.classList.contains("active")) {
     this.innerHTML =
      '<i class="fas fa-heart" style="color: #e74c3c;"></i> Liked';
     showNotification("Liked successfully!");
    } else {
     this.innerHTML = '<i class="fas fa-heart"></i> Like back';
    }
   });

   // Add reply button functionality
   const commentBtn = newPost.querySelector(".comment-btn");
   commentBtn.addEventListener("click", function () {
    if (!newPost.querySelector(".reply-form")) {
     const replyForm = document.createElement("div");
     replyForm.className = "reply-form";
     replyForm.innerHTML = `
      <textarea placeholder="Write your reply..."></textarea>
      <div class="reply-actions">
       <button class="submit-reply">Send</button>
       <button class="cancel-reply">Cancel</button>
      </div>
     `;

     this.closest(".post-interactions").after(replyForm);

     replyForm.querySelector(".submit-reply").addEventListener("click", () => {
      const replyText = replyForm.querySelector("textarea").value;
      if (replyText.trim()) {
       showNotification("Reply sent successfully!");
       replyForm.remove();
      }
     });

     replyForm.querySelector(".cancel-reply").addEventListener("click", () => {
      replyForm.remove();
     });
    }
   });

   // Add share button functionality
   const shareBtn = newPost.querySelector(".share-btn");
   shareBtn.addEventListener("click", function () {
    const postPreview = newPost.querySelector(".post-preview p").textContent;

    const shareOptions = document.createElement("div");
    shareOptions.className = "share-options";
    shareOptions.innerHTML = `
     <div class="share-popup">
      <button class="share-option" data-platform="facebook">
       <i class="fab fa-facebook"></i> Facebook
      </button>
      <button class="share-option" data-platform="twitter">
       <i class="fab fa-twitter"></i> Twitter
      </button>
      <button class="share-option" data-platform="linkedin">
       <i class="fab fa-linkedin"></i> LinkedIn
      </button>
      <button class="share-option" data-platform="copy">
       <i class="fas fa-link"></i> Copy Link
      </button>
      <button class="close-share">
       <i class="fas fa-times"></i>
      </button>
     </div>
    `;

    // Remove existing share options
    document
     .querySelectorAll(".share-options")
     .forEach((popup) => popup.remove());
    document.body.appendChild(shareOptions);

    // Position the popup
    const buttonRect = this.getBoundingClientRect();
    shareOptions.style.position = "absolute";
    shareOptions.style.top = `${buttonRect.bottom + window.scrollY + 10}px`;
    shareOptions.style.left = `${buttonRect.left}px`;

    // Handle share options
    shareOptions.querySelectorAll(".share-option").forEach((option) => {
     option.addEventListener("click", () => {
      shareContent(option.dataset.platform, postPreview);
      shareOptions.remove();
     });
    });

    // Close handlers
    shareOptions.querySelector(".close-share").addEventListener("click", () => {
     shareOptions.remove();
    });

    document.addEventListener("click", function closeShare(e) {
     if (!shareOptions.contains(e.target) && !shareBtn.contains(e.target)) {
      shareOptions.remove();
      document.removeEventListener("click", closeShare);
     }
    });
   });

   // Update page counter
   page++;
   if (page > 5) {
    loadMoreBtn.style.display = "none";
   }
  } catch (error) {
   console.error("Error loading more activities:", error);
   btnText.textContent = "Error loading activities. Try again.";
  } finally {
   // Reset button state
   spinner.style.display = "none";
   btnText.textContent = "Load More Activities";
   loadMoreBtn.disabled = false;
  }
 });
});
