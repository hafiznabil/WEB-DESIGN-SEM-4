// Handle form submission
document.addEventListener("DOMContentLoaded", () => {
 const supportForm = document.querySelector(".support-form");

 supportForm.addEventListener("submit", (e) => {
  e.preventDefault();

  // Get form values
  const issueType = supportForm.querySelector(
   'select[name="issue-type"]'
  ).value;
  const subject = supportForm.querySelector('input[type="text"]').value;
  const description = supportForm.querySelector("textarea").value;

  // Validate form
  if (!issueType || !subject || !description) {
   alert("Please fill in all fields");
   return;
  }

  // Here you would typically send the data to your backend
  // For now, we'll just show a success message
  alert("Support ticket submitted successfully! We will get back to you soon.");

  // Clear form
  supportForm.reset();
 });
});

// Optional: Add character counter for textarea
document.querySelector("textarea").addEventListener("input", function () {
 const maxLength = 500; // Set your desired maximum length
 const remainingChars = maxLength - this.value.length;

 if (remainingChars < 0) {
  this.value = this.value.slice(0, maxLength);
  return;
 }

 // If you want to show the character count, you can add this HTML element
 if (!document.querySelector(".char-counter")) {
  const counter = document.createElement("div");
  counter.className = "char-counter";
  this.parentNode.insertBefore(counter, this.nextSibling);
 }

 document.querySelector(
  ".char-counter"
 ).textContent = `${remainingChars} characters remaining`;
});
