// Activity Filters (Activity.html)
document.addEventListener("DOMContentLoaded", () => {
 const filterButtons = document.querySelectorAll(".filter-btn");
 const activityPosts = document.querySelectorAll(".activity-post");

 filterButtons.forEach((button) => {
  button.addEventListener("click", () => {
   // Remove active class from all buttons
   filterButtons.forEach((btn) => btn.classList.remove("active"));
   // Add active class to clicked button
   button.classList.add("active");

   const filterType = button.textContent.toLowerCase();

   activityPosts.forEach((post) => {
    const actionType = post
     .querySelector(".user-profile span")
     .textContent.toLowerCase();

    if (filterType === "all") {
     post.style.display = "block";
    } else {
     // Check if the action type contains the filter type
     // (e.g., "liked your post" contains "like")
     post.style.display = actionType.includes(filterType.slice(0, -1))
      ? "block"
      : "none";
    }
   });
  });
 });

 // Search functionality
 const searchInput = document.querySelector(".search-box input");
 searchInput.addEventListener("input", (e) => {
  const searchTerm = e.target.value.toLowerCase();

  activityPosts.forEach((post) => {
   const userName = post
    .querySelector(".user-profile p")
    .textContent.toLowerCase();
   const content = post
    .querySelector(".activity-post p")
    .textContent.toLowerCase();

   if (userName.includes(searchTerm) || content.includes(searchTerm)) {
    post.style.display = "block";
   } else {
    post.style.display = "none";
   }
  });
 });

 // Interaction counters
 let likeCount = 247;
 let commentCount = 89;
 let shareCount = 15;

 // Update stats display
 function updateStats() {
  document
   .querySelector(".fa-heart")
   .parentElement.querySelector("h3").textContent = likeCount;
  document
   .querySelector(".fa-comment")
   .parentElement.querySelector("h3").textContent = commentCount;
  document
   .querySelector(".fa-share")
   .parentElement.querySelector("h3").textContent = shareCount;
 }

 // Add interaction functionality to posts
 activityPosts.forEach((post) => {
  // Create interaction buttons if they don't exist
  if (!post.querySelector(".post-interactions")) {
   const interactions = document.createElement("div");
   interactions.className = "post-interactions";
   interactions.innerHTML = `
                   <button class="interaction-btn like-btn">
                       <i class="fas fa-heart"></i> Like
                   </button>
                   <button class="interaction-btn comment-btn">
                       <i class="fas fa-comment"></i> Comment
                   </button>
                   <button class="interaction-btn share-btn">
                       <i class="fas fa-share"></i> Share
                   </button>
               `;
   post.appendChild(interactions);
  }

  // Add click events for interaction buttons
  const likeBtn = post.querySelector(".like-btn");
  const commentBtn = post.querySelector(".comment-btn");
  const shareBtn = post.querySelector(".share-btn");

  likeBtn.addEventListener("click", () => {
   likeBtn.classList.toggle("active");
   if (likeBtn.classList.contains("active")) {
    likeCount++;
   } else {
    likeCount--;
   }
   updateStats();
  });

  commentBtn.addEventListener("click", () => {
   // Create comment input if it doesn't exist
   if (!post.querySelector(".comment-input")) {
    const commentSection = document.createElement("div");
    commentSection.className = "comment-section";
    commentSection.innerHTML = `
                       <input type="text" placeholder="Write a comment..." class="comment-input">
                       <button class="submit-comment">Post</button>
                   `;
    post.appendChild(commentSection);

    const submitComment = commentSection.querySelector(".submit-comment");
    const commentInput = commentSection.querySelector(".comment-input");

    submitComment.addEventListener("click", () => {
     if (commentInput.value.trim()) {
      commentCount++;
      updateStats();
      // Add comment to post (you can implement this further)
      commentInput.value = "";
     }
    });
   }
  });

  shareBtn.addEventListener("click", () => {
   shareCount++;
   updateStats();
   alert("Post shared successfully!");
  });
 });

 // Load More button functionality
 const loadMoreBtn = document.querySelector(".load-more-btn");
 loadMoreBtn.addEventListener("click", () => {
  // Add logic to load more posts
  alert("Loading more activities...");
 });
});

document.addEventListener("DOMContentLoaded", function () {
 const filterButtons = document.querySelectorAll(".filter-btn");
 const exploreItems = document.querySelectorAll(".explore-item");

 filterButtons.forEach((button) => {
  button.addEventListener("click", () => {
   // Remove active class from all buttons
   filterButtons.forEach((btn) => btn.classList.remove("active"));
   // Add active class to clicked button
   button.classList.add("active");

   const category = button.textContent.toLowerCase();

   exploreItems.forEach((item) => {
    if (category === "all") {
     item.style.display = "block";
    } else {
     item.style.display = item.dataset.category === category ? "block" : "none";
    }
   });
  });
 });
});

function settingsMenuToggle() {
 const settingsMenu = document.querySelector(".settings-menu");
 settingsMenu.classList.toggle("settings-menu-height");
}

function toggleDarkMode() {
 document.body.classList.toggle("dark-mode");
 // Save preference to localStorage
 const isDarkMode = document.body.classList.contains("dark-mode");
 localStorage.setItem("darkMode", isDarkMode);

 // Update the text of the toggle button
 const darkModeLink = document.querySelector('[onclick="toggleDarkMode()"] a');
 darkModeLink.textContent = isDarkMode
  ? "Toggle Light Mode"
  : "Toggle Dark Mode";
}

// Check for saved dark mode preference when page loads
document.addEventListener("DOMContentLoaded", () => {
 const isDarkMode = localStorage.getItem("darkMode") === "true";
 if (isDarkMode) {
  document.body.classList.add("dark-mode");
  const darkModeLink = document.querySelector('[onclick="toggleDarkMode()"] a');
  if (darkModeLink) {
   darkModeLink.textContent = "Toggle Light Mode";
  }
 }
});

// Handle follow button clicks
document.addEventListener("DOMContentLoaded", function () {
 const followButtons = document.querySelectorAll(".follow-btn");

 followButtons.forEach((button) => {
  button.addEventListener("click", function () {
   if (this.textContent === "Follow") {
    this.textContent = "Following";
    this.classList.add("following");
    // Optional: Add success message
    showNotification("Successfully followed!");
   } else {
    this.textContent = "Follow";
    this.classList.remove("following");
    // Optional: Add unfollow message
    showNotification("Unfollowed");
   }
  });

  // Optional: Add hover effect for "Following" state
  button.addEventListener("mouseenter", function () {
   if (this.classList.contains("following")) {
    this.textContent = "Unfollow";
    this.classList.add("unfollow-hover");
   }
  });

  button.addEventListener("mouseleave", function () {
   if (this.classList.contains("following")) {
    this.textContent = "Following";
    this.classList.remove("unfollow-hover");
   }
  });
 });
});

// Optional: Show notification function
function showNotification(message) {
 const notification = document.createElement("div");
 notification.className = "notification";
 notification.textContent = message;

 document.body.appendChild(notification);

 // Remove notification after 2 seconds
 setTimeout(() => {
  notification.remove();
 }, 2000);
}
