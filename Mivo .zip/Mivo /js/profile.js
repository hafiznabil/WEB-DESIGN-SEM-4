function settingsMenuToggle() {
 const settingsMenu = document.querySelector(".settings-menu");
 settingsMenu.classList.toggle("settings-menu-height");
}

function toggleDarkMode() {
 document.body.classList.toggle("dark-mode");
 // Save preference to localStorage
 const isDarkMode = document.body.classList.contains("dark-mode");
 localStorage.setItem("darkMode", isDarkMode);

 // Update the text of the toggle button
 const darkModeLink = document.querySelector('[onclick="toggleDarkMode()"] a');
 darkModeLink.textContent = isDarkMode
  ? "Toggle Light Mode"
  : "Toggle Dark Mode";
}

// Check for saved dark mode preference when page loads
document.addEventListener("DOMContentLoaded", () => {
 const isDarkMode = localStorage.getItem("darkMode") === "true";
 if (isDarkMode) {
  document.body.classList.add("dark-mode");
  const darkModeLink = document.querySelector('[onclick="toggleDarkMode()"] a');
  if (darkModeLink) {
   darkModeLink.textContent = "Toggle Light Mode";
  }
 }
});

// Emoji picker toggle
function toggleEmojiPicker() {
 const emojiPicker = document.querySelector("emoji-picker");
 emojiPicker.style.display =
  emojiPicker.style.display === "none" ? "block" : "none";

 // Handle emoji selection
 emojiPicker.addEventListener("emoji-click", (event) => {
  const textarea = document.querySelector(".post-input-container textarea");
  textarea.value += event.detail.unicode;
 });
}

// Like functionality
function handleLike(postElement) {
 const likeButton = postElement.querySelector(
  ".activity-icons div:first-child"
 );
 const likeCount = likeButton.textContent;

 likeButton.addEventListener("click", () => {
  const currentCount = parseInt(likeCount);
  likeButton.innerHTML = `<img src="images/like-blue.png" alt="" />${
   currentCount + 1
  }`;
  likeButton.classList.add("liked");
 });
}

// Comment functionality
function handleComment(postElement) {
 const commentButton = postElement.querySelector(
  ".activity-icons div:nth-child(2)"
 );

 commentButton.addEventListener("click", () => {
  const commentArea = document.createElement("div");
  commentArea.className = "comment-area";
  commentArea.innerHTML = `
    <div class="modern-comment-input">
      <img src="images/profile-pic.png" alt="" class="comment-profile-pic">
      <textarea placeholder="Write a comment..." rows="1"></textarea>
      <button class="modern-comment-btn cancel" onclick="cancelComment(this)">
        <i class="fa-solid fa-xmark"></i>
      </button>
      <button class="modern-comment-btn" onclick="postComment(this)">
        <i class="fa-solid fa-paper-plane"></i>
      </button>
    </div>
  `;

  const activityIcons = postElement.querySelector(".activity-icons");
  activityIcons.parentNode.insertBefore(commentArea, activityIcons.nextSibling);
 });
}

// Add new cancel function
function cancelComment(button) {
 const commentArea = button.closest(".comment-area");
 commentArea.remove();
}

// Post comment
function postComment(button) {
 const commentArea = button.parentElement;
 const commentText = commentArea.querySelector("textarea").value;

 if (commentText.trim()) {
  const commentElement = document.createElement("div");
  commentElement.className = "comment";
  commentElement.innerHTML = `
            <img src="images/profile-pic.png" alt="" class="comment-profile-pic" />
            <div class="comment-content">
                <p class="comment-author">Hafiz Nabil</p>
                <p class="comment-text">${commentText}</p>
            </div>
        `;

  commentArea.parentNode.insertBefore(commentElement, commentArea.nextSibling);
  commentArea.querySelector("textarea").value = "";
 }
}

// Share functionality
function handleShare(postElement) {
 const shareButton = postElement.querySelector(
  ".activity-icons div:last-child"
 );

 shareButton.addEventListener("click", () => {
  // Create share dialog
  if (navigator.share) {
   navigator
    .share({
     title: "Share this post",
     text: postElement.querySelector(".post-text").textContent,
     url: window.location.href,
    })
    .catch((error) => console.log("Error sharing:", error));
  } else {
   alert("Web Share API not supported in your browser");
  }
 });
}

// Live Video (Camera Access)
async function startLiveVideo() {
 try {
  const stream = await navigator.mediaDevices.getUserMedia({
   video: true,
   audio: true,
  });

  // Create video element
  const videoModal = document.createElement("div");
  videoModal.className = "video-modal";
  videoModal.innerHTML = `
            <div class="video-container">
                <video autoplay></video>
                <button onclick="stopLiveVideo(this)">End Stream</button>
            </div>
        `;

  document.body.appendChild(videoModal);
  const video = videoModal.querySelector("video");
  video.srcObject = stream;
 } catch (error) {
  console.error("Error accessing camera:", error);
  alert("Unable to access camera and microphone");
 }
}

// Stop Live Video
function stopLiveVideo(button) {
 const videoModal = button.closest(".video-modal");
 const video = videoModal.querySelector("video");
 const stream = video.srcObject;

 stream.getTracks().forEach((track) => track.stop());
 videoModal.remove();
}

// Photo/Video Upload
function handleMediaUpload() {
 const input = document.createElement("input");
 input.type = "file";
 input.accept = "image/*,video/*";
 input.multiple = true;

 input.onchange = (e) => {
  const files = Array.from(e.target.files);
  files.forEach((file) => {
   const reader = new FileReader();

   reader.onload = (event) => {
    const textarea = document.querySelector(".post-input-container textarea");
    const mediaPreview = document.createElement("div");
    mediaPreview.className = "media-preview";

    if (file.type.startsWith("image/")) {
     mediaPreview.innerHTML = `<img src="${event.target.result}" alt="Preview" />`;
    } else if (file.type.startsWith("video/")) {
     mediaPreview.innerHTML = `<video src="${event.target.result}" controls></video>`;
    }

    textarea.parentNode.insertBefore(mediaPreview, textarea.nextSibling);
   };

   reader.readAsDataURL(file);
  });
 };

 input.click();
}

// Initialize all post interactions
function initializePostInteractions() {
 const posts = document.querySelectorAll(".post-container");
 posts.forEach((post) => {
  handleLike(post);
  handleComment(post);
  handleShare(post);
 });

 // Add click listeners for media buttons
 const liveVideoButton = document.querySelector(
  ".add-post-links a:nth-child(1)"
 );
 const photoVideoButton = document.querySelector(
  ".add-post-links a:nth-child(2)"
 );

 liveVideoButton.addEventListener("click", (e) => {
  e.preventDefault();
  startLiveVideo();
 });

 photoVideoButton.addEventListener("click", (e) => {
  e.preventDefault();
  handleMediaUpload();
 });
}

// Add necessary CSS styles
const styles = `
    .video-modal {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.8);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 1000;
    }
    
    .video-container {
        max-width: 800px;
        width: 90%;
        background: #fff;
        padding: 20px;
        border-radius: 10px;
    }
    
    .video-container video {
        width: 100%;
        margin-bottom: 10px;
    }
    
    .comment-area {
        margin: 10px 0;
        padding: 10px;
        background: #f0f2f5;
        border-radius: 5px;
    }
    
    .comment-area textarea {
        width: 100%;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 4px;
        margin-bottom: 5px;
    }
    
    .comment {
        display: flex;
        align-items: start;
        margin: 10px 0;
        padding: 10px;
    }
    
    .comment-profile-pic {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        margin-right: 10px;
    }
    
    .media-preview {
        margin: 10px 0;
    }
    
    .media-preview img,
    .media-preview video {
        max-width: 100%;
        max-height: 300px;
        border-radius: 8px;
    }

    .modern-comment-input {
        display: flex;
        align-items: center;
        gap: 8px;
        background: #f8f9fa;
        border-radius: 24px;
        padding: 8px 16px;
        margin: 12px 0;
        border: 1px solid #e4e6eb;
    }

    .modern-comment-input .comment-profile-pic {
        width: 32px;
        height: 32px;
        border-radius: 50%;
    }

    .modern-comment-input textarea {
        flex: 1;
        border: none;
        background: transparent;
        resize: none;
        outline: none;
        font-family: inherit;
        font-size: 14px;
        padding: 8px 0;
        min-height: 20px;
        color: #333;
    }

    .modern-comment-input textarea::placeholder {
        color: #65676b;
    }

    .modern-comment-btn {
        background: #0866ff;
        border: none;
        border-radius: 50%;
        width: 36px;
        height: 36px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: background-color 0.2s;
    }

    .modern-comment-btn:hover {
        background: #0859d9;
    }

    .modern-comment-btn i {
        color: white;
        font-size: 16px;
    }

    /* Dark mode support */
    .dark-mode .modern-comment-input {
        background: #242526;
        border-color: #3e4042;
    }

    .dark-mode .modern-comment-input textarea {
        color: #e4e6eb;
    }

    .dark-mode .modern-comment-input textarea::placeholder {
        color: #b0b3b8;
    }

    .modern-comment-btn.cancel {
        background: #e4e6eb;
    }

    .modern-comment-btn.cancel:hover {
        background: #d8dadf;
    }

    .modern-comment-btn.cancel i {
        color: #65676b;
    }

    /* Dark mode support for cancel button */
    .dark-mode .modern-comment-btn.cancel {
        background: #3a3b3c;
    }

    .dark-mode .modern-comment-btn.cancel i {
        color: #e4e6eb;
    }
`;

// Add styles to document
const styleSheet = document.createElement("style");
styleSheet.textContent = styles;
document.head.appendChild(styleSheet);

// Initialize everything when the document is loaded
document.addEventListener("DOMContentLoaded", initializePostInteractions);

//create post
function createPost() {
 const postText = document.getElementById("post-text").value;
 const mediaPreviews = document.querySelectorAll(".media-preview");

 // Only create post if there's text or media
 if (!postText.trim() && mediaPreviews.length === 0) return;

 const postContainer = document.createElement("div");
 postContainer.className = "post-container";

 const currentDate = new Date().toLocaleString("en-US", {
  month: "short",
  day: "numeric",
  year: "numeric",
  hour: "numeric",
  minute: "numeric",
  hour12: true,
 });

 // Create media content HTML if media exists
 let mediaContent = "";
 mediaPreviews.forEach((preview) => {
  const mediaElement = preview.querySelector("img, video");
  if (mediaElement) {
   mediaContent += mediaElement.outerHTML;
  }
 });

 postContainer.innerHTML = `
           <div class="post-row">
               <div class="user-profile">
                   <img src="images/profile-pic.png" alt="" />
                   <div>
                       <p>Hafiz Nabil</p>
                       <span>${currentDate}</span>
                   </div>
               </div>
               <a href="#"><i class="fa-solid fa-ellipsis-v"></i></a>
           </div>
           <p class="post-text">${postText}</p>
           ${
            mediaContent ? `<div class="post-media">${mediaContent}</div>` : ""
           }
           <div class="post-row">
               <div class="activity-icons">
                   <div><img src="images/like-blue.png" alt="" />0</div>
                   <div><img src="images/comments.png" alt="" />0</div>
                   <div><img src="images/share.png" alt="" />0</div>
               </div>
               <div class="post-profile-icon">
                   <img src="images/profile-pic.png" alt="" />
                   <i class="fa-solid fa-caret-down"></i>
               </div>
           </div>
       `;
 // Add these styles to your existing styles const
 const styles = `
// ... existing styles ...

.post-media-container {
    margin: 10px 0;
    text-align: center;
    max-height: 500px;
    overflow: hidden;
}

.post-media-content {
    max-width: 100%;
    height: auto;
    object-fit: contain;
    border-radius: 8px;
    margin: 5px 0;
}

/* For multiple images in a single post */
.post-media-container img + img,
.post-media-container video + video,
.post-media-container img + video,
.post-media-container video + img {
    margin-top: 10px;
}
`;

 // Insert the new post at the top of the posts list
 const postCol = document.querySelector(".post-col");
 postCol.insertBefore(postContainer, postCol.children[1]);

 // Clear the textarea and remove media previews
 document.getElementById("post-text").value = "";
 mediaPreviews.forEach((preview) => preview.remove());
}
