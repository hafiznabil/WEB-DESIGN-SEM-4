// Cart functionality
let cartCount = 0;
let cartItems = [];

// Update cart count in the UI
function updateCartCount() {
 const cartCountElement = document.querySelector(".cart-count");
 if (cartCountElement) {
  cartCountElement.textContent = cartCount;
 }
}

// Load cart data from localStorage
function loadCartData() {
 const savedCartItems = localStorage.getItem("cartItems");
 if (savedCartItems) {
  cartItems = JSON.parse(savedCartItems);
  cartCount = cartItems.reduce((total, item) => total + item.quantity, 0);
  updateCartCount();
 }
}

// Add to cart functionality
function addToCart(product) {
 // Generate unique ID if not present
 if (!product.id) {
  product.id = Date.now();
 }

 // Check if item already exists in cart
 const existingItem = cartItems.find((item) => item.id === product.id);

 if (existingItem) {
  existingItem.quantity++;
 } else {
  cartItems.push({ ...product, quantity: 1 });
 }

 cartCount = cartItems.reduce((total, item) => total + item.quantity, 0);
 updateCartCount();

 // Save cart items to localStorage
 localStorage.setItem("cartItems", JSON.stringify(cartItems));

 // Update cart display if on cart page
 if (window.location.pathname.includes("cart.html")) {
  displayCartItems();
 }

 showNotification("Item added to cart!");
}

// Buy now functionality
function buyNow(product) {
 addToCart(product);
 window.location.href = "cart.html";
}

// Initialize filter functionality
function initializeFilters() {
 const filterDropdowns = document.querySelectorAll(".filter-dropdown");

 filterDropdowns.forEach((dropdown) => {
  dropdown.addEventListener("change", function () {
   applyFilters();
  });
 });
}

// Apply filters to marketplace items
function applyFilters() {
 const category = document.querySelector(
  '.filter-dropdown[name="category"]'
 ).value;
 const priceRange = document.querySelector(
  '.filter-dropdown[name="price"]'
 ).value;
 const sortBy = document.querySelector('.filter-dropdown[name="sort"]').value;

 const items = document.querySelectorAll(".marketplace-item");

 items.forEach((item) => {
  const itemPrice = parseFloat(
   item.querySelector(".price").textContent.replace("RM ", "").replace(",", "")
  );

  // Filter by price range
  if (priceRange === "0-25" && (itemPrice < 0 || itemPrice > 25)) {
   item.style.display = "none";
  } else if (priceRange === "25-50" && (itemPrice < 25 || itemPrice > 50)) {
   item.style.display = "none";
  } else if (priceRange === "50+" && itemPrice < 50) {
   item.style.display = "none";
  } else {
   item.style.display = "block";
  }
 });
}

// Newsletter subscription
function handleSubscription() {
 const emailInput = document.querySelector(
  '.newsletter-form input[type="email"]'
 );
 const subscribeButton = document.querySelector(".newsletter-form button");

 subscribeButton.addEventListener("click", (e) => {
  e.preventDefault();
  const email = emailInput.value.trim();

  if (validateEmail(email)) {
   console.log("Subscribing email:", email);
   showNotification("Thank you for subscribing!");
   emailInput.value = "";
  } else {
   showNotification("Please enter a valid email address", "error");
  }
 });
}

// Helper function to validate email
function validateEmail(email) {
 const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
 return re.test(email);
}

// Notification system
function showNotification(message, type = "success") {
 const notification = document.createElement("div");
 notification.className = `notification ${type}`;
 notification.textContent = message;

 document.body.appendChild(notification);

 setTimeout(() => {
  notification.remove();
 }, 3000);
}

// Initialize all functionality when DOM is loaded
document.addEventListener("DOMContentLoaded", () => {
 // Load cart data first
 loadCartData();

 // Initialize filters
 initializeFilters();

 // Initialize newsletter subscription
 handleSubscription();

 // Add event listeners to all "Add to Cart" buttons
 document.querySelectorAll(".buy-btn").forEach((button) => {
  button.addEventListener("click", function () {
   const item = this.closest(".marketplace-item");
   const product = {
    id: parseInt(item.dataset.productId) || Date.now(),
    name: item.querySelector("h3").textContent,
    price: parseFloat(
     item
      .querySelector(".price")
      .textContent.replace("RM ", "")
      .replace(",", "")
    ),
    image: item.querySelector("img").src,
   };

   if (this.classList.contains("add-to-cart")) {
    addToCart(product);
   } else if (this.classList.contains("buy-now")) {
    buyNow(product);
   }
  });
 });

 // Initialize cart display if on cart page
 if (window.location.pathname.includes("cart.html")) {
  displayCartItems();
 }
});

// Add this to your CSS file for notifications
const styles = `
.notification {
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 15px 25px;
    border-radius: 4px;
    color: white;
    z-index: 1000;
    animation: slideIn 0.5s ease-out;
}

.notification.success {
    background-color: #4CAF50;
}

.notification.error {
    background-color: #f44336;
}

@keyframes slideIn {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}
`;

function settingsMenuToggle() {
 const settingsMenu = document.querySelector(".settings-menu");
 settingsMenu.classList.toggle("settings-menu-height");
}

function toggleDarkMode() {
 document.body.classList.toggle("dark-mode");
 const isDarkMode = document.body.classList.contains("dark-mode");
 localStorage.setItem("darkMode", isDarkMode);

 const darkModeLink = document.querySelector('[onclick="toggleDarkMode()"] a');
 darkModeLink.textContent = isDarkMode
  ? "Toggle Light Mode"
  : "Toggle Dark Mode";
}

// Check for saved dark mode preference when page loads
document.addEventListener("DOMContentLoaded", () => {
 const isDarkMode = localStorage.getItem("darkMode") === "true";
 if (isDarkMode) {
  document.body.classList.add("dark-mode");
  const darkModeLink = document.querySelector('[onclick="toggleDarkMode()"] a');
  if (darkModeLink) {
   darkModeLink.textContent = "Toggle Light Mode";
  }
 }
});

// Display cart items
function displayCartItems() {
 const cartContainer = document.querySelector(".cart-items-container");
 if (!cartContainer) return;

 // Get cart items from localStorage
 const savedCartItems = localStorage.getItem("cartItems");
 if (savedCartItems) {
  cartItems = JSON.parse(savedCartItems);
  cartCount = cartItems.reduce((total, item) => total + item.quantity, 0);
  updateCartCount();

  // Display each cart item
  cartContainer.innerHTML = cartItems
   .map(
    (item) => `
    <div class="cart-item">
      <img src="${item.image}" alt="${item.name}" class="cart-item-image">
      <div class="cart-item-details">
        <h3>${item.name}</h3>
        <p class="price">RM ${item.price.toFixed(2)}</p>
        <div class="quantity">
          <button onclick="updateQuantity(${item.id}, -1)">-</button>
          <span>${item.quantity}</span>
          <button onclick="updateQuantity(${item.id}, 1)">+</button>
        </div>
      </div>
      <button onclick="removeItem(${
       item.id
      })" class="remove-btn">Remove</button>
    </div>
  `
   )
   .join("");

  // Update total if element exists
  const totalElement = document.querySelector("#cartTotal");
  if (totalElement) {
   const total = cartItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
   );
   totalElement.textContent = total.toFixed(2);
  }
 }
}

// Update quantity in cart
function updateQuantity(productId, change) {
 const item = cartItems.find((item) => item.id === productId);
 if (item) {
  item.quantity = Math.max(0, item.quantity + change);
  if (item.quantity === 0) {
   removeItem(productId);
  } else {
   localStorage.setItem("cartItems", JSON.stringify(cartItems));
   displayCartItems();
   updateCartCount();
  }
 }
}

// Remove item from cart
function removeItem(productId) {
 cartItems = cartItems.filter((item) => item.id !== productId);
 localStorage.setItem("cartItems", JSON.stringify(cartItems));
 displayCartItems();
 updateCartCount();
}
